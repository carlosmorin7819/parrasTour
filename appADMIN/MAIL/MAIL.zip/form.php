<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>enviar</title>
</head>
<body>
	
	<form action="mail.php" method="post">
		<input type="text" name="name" id="name" placeholder="Nombre"> <br> <br>
		<input type="text" name="mail" id="mail" placeholder="mail"> <br> <br>
		<input type="submit" value="Enviar">
	</form>
</body>
</html>